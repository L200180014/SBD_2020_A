/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perhotelan;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author dikawfa
 */
public class Transaksi extends javax.swing.JFrame {
    private void kosongkan_form(){
        cbNamaTamu.setSelectedItem("-- Pilih Nama --");
        cbJenisKamar.setSelectedItem("Standar");
        cbNoKamar.setSelectedItem("--");
        tglCheckIn.setDate(null);
        lamaMenginap.setValue(0);
    }

    private void tampilkanDataTransaksi() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No. Transaksi");
        model.addColumn("ID Tamu");
        model.addColumn("No Kamar");
        model.addColumn("Check In");
        model.addColumn("Lama Menginap");
        model.addColumn("Biaya");

        try {
            String sql = "SELECT * FROM Transaksi;";
            java.sql.Connection conn;
            conn = (Connection)Koneksi.configDB();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            while(res.next()){
                model.addRow(new Object[]{res.getString(1),res.getString(2),res.getString(3),
                    res.getString(4),res.getString(5),res.getString(6)
                });
            }
            tabelTransaksi.setModel(model);
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    private void tampil_idTamu() {
        String namaTamu = cbNamaTamu.getSelectedItem().toString();
        try {
            Connection con = Koneksi.configDB();
            java.sql.Statement stt = con.createStatement();
            String sql = "SELECT id_tamu FROM Tamu WHERE nama_tamu='"+namaTamu+"'";
            java.sql.ResultSet res = stt.executeQuery(sql);
            
            while(res.next()){
                Object[] ob = new Object[3];
                ob[0] = res.getString(1);
                idTamu.setText((String) ob[0]);
            }
            
            res.close(); stt.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
        
    }
    
    private void tampil_comboNama() {
        try {
            Connection con = Koneksi.configDB();
            java.sql.Statement stt = con.createStatement();
            String sql = "select nama_tamu from Tamu";
            java.sql.ResultSet res = stt.executeQuery(sql);

            while(res.next()){
                Object[] ob = new Object[3];
                ob[0] = res.getString(1);
                cbNamaTamu.addItem((String) ob[0]);
            }
            res.close(); stt.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    private void tampil_comboNoKamar() {
        cbNoKamar.removeAllItems();
        cbNoKamar.addItem("--");
        String jenisKamar = cbJenisKamar.getSelectedItem().toString();
        try {
            Connection con = Koneksi.configDB();
            java.sql.Statement stt = con.createStatement();
            String sql = "SELECT no_kamar FROM Kamar WHERE jenis_kamar='"+jenisKamar+"'";
            java.sql.ResultSet res = stt.executeQuery(sql);

            while(res.next()){
                Object[] ob = new Object[3];
                ob[0] = res.getString(1);
                cbNoKamar.addItem((String) ob[0]);
            }
            res.close(); stt.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    private void tampil_tarifKamar() {
        String jenisKamar = cbJenisKamar.getSelectedItem().toString();
        try {
            Connection con = Koneksi.configDB();
            java.sql.Statement stt = con.createStatement();
            String sql = "SELECT tarif_kamar FROM Kamar WHERE jenis_kamar='"+jenisKamar+"'";
            java.sql.ResultSet res = stt.executeQuery(sql);
            
            while(res.next()){
                Object[] ob = new Object[3];
                ob[0] = res.getString(1);
                txtTarif.setText((String) ob[0]);
            }

            res.close(); stt.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void tampil_biayaTotal() {
        int lama = (Integer) lamaMenginap.getValue();
        int hitungHarga = lama * Integer.parseInt(txtTarif.getText());
        totalBiaya.setText(String.valueOf(hitungHarga));
    }
    
    public static Date getTanggalFromTableTransaksi(JTable table, int kolom){
        JTable tabel = table;
        String str_tgl = String.valueOf(tabel.getValueAt(tabel.getSelectedRow(), kolom));
        Date tanggal = null;
        try {
            tanggal = new SimpleDateFormat("dd MMMM yyyy").parse(str_tgl);
        } catch (ParseException ex) {
            Logger.getLogger(Transaksi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return tanggal;
    }

    /**
     * Creates new form Transaksi
     */
    public Transaksi() {
        initComponents();
        tampilkanDataTransaksi();
        tampil_comboNama();
        tampil_comboNoKamar();
        tampil_tarifKamar();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelTransaksi = new javax.swing.JTable();
        cbNamaTamu = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        cbNoKamar = new javax.swing.JComboBox<>();
        tglCheckIn = new com.toedter.calendar.JDateChooser();
        totalBiaya = new javax.swing.JTextField();
        cbJenisKamar = new javax.swing.JComboBox<>();
        tbDataTamu = new javax.swing.JButton();
        tbDataKamar = new javax.swing.JButton();
        tbResetInput = new javax.swing.JButton();
        tbSimpanTransaksi = new javax.swing.JButton();
        tbUpdate = new javax.swing.JButton();
        tbHapus = new javax.swing.JButton();
        lamaMenginap = new javax.swing.JSpinner();
        jLabel2 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        idTamu = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtTarif = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Cinzel", 1, 18)); // NOI18N
        jLabel1.setText("TRANSAKSI");

        jLabel3.setText("Nama Tamu");

        jLabel4.setText("Jenis Kamar");

        jLabel5.setText("Check In");

        jLabel6.setText("Lama menginap");

        jLabel7.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        jLabel7.setText("Biaya (Rp)");

        tabelTransaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabelTransaksi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelTransaksiMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabelTransaksi);

        cbNamaTamu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Pilih Nama --" }));
        cbNamaTamu.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbNamaTamuItemStateChanged(evt);
            }
        });
        cbNamaTamu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbNamaTamuActionPerformed(evt);
            }
        });

        jLabel8.setText("No. Kamar");

        cbNoKamar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--" }));
        cbNoKamar.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbNoKamarItemStateChanged(evt);
            }
        });
        cbNoKamar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbNoKamarActionPerformed(evt);
            }
        });

        tglCheckIn.setDateFormatString("dd MMMM yyyy");

        totalBiaya.setEditable(false);
        totalBiaya.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalBiayaActionPerformed(evt);
            }
        });

        cbJenisKamar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--", "Standar", "VIP" }));
        cbJenisKamar.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbJenisKamarItemStateChanged(evt);
            }
        });
        cbJenisKamar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbJenisKamarActionPerformed(evt);
            }
        });

        tbDataTamu.setText("Data Tamu");
        tbDataTamu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbDataTamuActionPerformed(evt);
            }
        });

        tbDataKamar.setText("Data Kamar");
        tbDataKamar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbDataKamarActionPerformed(evt);
            }
        });

        tbResetInput.setText("Reset");
        tbResetInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbResetInputActionPerformed(evt);
            }
        });

        tbSimpanTransaksi.setText("Simpan");
        tbSimpanTransaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbSimpanTransaksiActionPerformed(evt);
            }
        });

        tbUpdate.setText("Update");
        tbUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbUpdateActionPerformed(evt);
            }
        });

        tbHapus.setText("Hapus");
        tbHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbHapusActionPerformed(evt);
            }
        });

        lamaMenginap.setModel(new javax.swing.SpinnerNumberModel(0, 0, 30, 1));
        lamaMenginap.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                lamaMenginapStateChanged(evt);
            }
        });

        jLabel2.setText("malam");

        jLabel9.setText("ID Tamu");

        idTamu.setEditable(false);
        idTamu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idTamuActionPerformed(evt);
            }
        });

        jLabel10.setText("Tarif /malam");

        txtTarif.setEditable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4))
                                .addGap(34, 34, 34)
                                .addComponent(totalBiaya, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel7)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(tglCheckIn, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lamaMenginap, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel2))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(idTamu))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(cbNoKamar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(cbJenisKamar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtTarif, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(cbNamaTamu, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(136, 136, 136)
                                .addComponent(jLabel1)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(tbDataTamu)
                        .addGap(18, 18, 18)
                        .addComponent(tbDataKamar)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 703, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tbResetInput, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(tbSimpanTransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(tbUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(tbHapus, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbNamaTamu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(idTamu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbJenisKamar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel10)
                    .addComponent(txtTarif, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbNoKamar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tglCheckIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(lamaMenginap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(totalBiaya, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tbHapus)
                    .addComponent(tbResetInput)
                    .addComponent(tbSimpanTransaksi)
                    .addComponent(tbUpdate))
                .addGap(28, 28, 28)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tbDataTamu)
                    .addComponent(tbDataKamar))
                .addGap(16, 16, 16))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbNamaTamuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbNamaTamuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbNamaTamuActionPerformed

    private void cbJenisKamarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbJenisKamarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbJenisKamarActionPerformed

    private void cbNoKamarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbNoKamarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbNoKamarActionPerformed

    private void idTamuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idTamuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idTamuActionPerformed

    private void cbJenisKamarItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbJenisKamarItemStateChanged
        // TODO add your handling code here:
        tampil_comboNoKamar();
        tampil_tarifKamar();
        tampil_biayaTotal();
    }//GEN-LAST:event_cbJenisKamarItemStateChanged

    private void cbNamaTamuItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbNamaTamuItemStateChanged
        // TODO add your handling code here:
        if ("-- Pilih Nama --".equals(cbNamaTamu.getSelectedItem().toString())) {
            idTamu.setText(null);
        } else {
            tampil_idTamu();
        }
    }//GEN-LAST:event_cbNamaTamuItemStateChanged

    private void totalBiayaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalBiayaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_totalBiayaActionPerformed

    private void lamaMenginapStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_lamaMenginapStateChanged
        // TODO add your handling code here:
        tampil_biayaTotal();
    }//GEN-LAST:event_lamaMenginapStateChanged

    private void tbResetInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbResetInputActionPerformed
        // TODO add your handling code here:
        kosongkan_form();
    }//GEN-LAST:event_tbResetInputActionPerformed

    private void tbSimpanTransaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbSimpanTransaksiActionPerformed
        // TODO add your handling code here:
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy");
            String dateCheckIn = sdf.format(tglCheckIn.getDate());
            String sql = "INSERT INTO Transaksi VALUES (" +
                    "NULL, '"+
                    idTamu.getText()+"', '" + 
                    cbNoKamar.getSelectedItem().toString()+"', '" +
                    dateCheckIn+"', '" +
                    lamaMenginap.getValue()+"', '" +
                    totalBiaya.getText()+"')";
            java.sql.Connection conn = (Connection)Koneksi.configDB();
            java.sql.PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data berhasil disimpan");
            tampilkanDataTransaksi();
            kosongkan_form();
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_tbSimpanTransaksiActionPerformed

    private void tbUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbUpdateActionPerformed
        // TODO add your handling code here:
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy");
            String dateCheckIn = sdf.format(tglCheckIn.getDate());
            String sql = "UPDATE Transaksi SET id_tamu='"+idTamu.getText()+ 
                    "', no_kamar='"+ cbNoKamar.getSelectedItem().toString()+
                    "', check_in='"+dateCheckIn+
                    "', lama_menginap='"+lamaMenginap.getValue()+
                    "', total_biaya='"+totalBiaya.getText()+
                    "'WHERE id_tamu='"+idTamu.getText()+"'";
            java.sql.Connection conn = (Connection)Koneksi.configDB();
            java.sql.PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data berhasil diupdate");
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        tampilkanDataTransaksi();
        kosongkan_form();
    }//GEN-LAST:event_tbUpdateActionPerformed

    private void tabelTransaksiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelTransaksiMouseClicked
        // TODO add your handling code here:
        idTamu.setText(tabelTransaksi.getValueAt(tabelTransaksi.getSelectedRow(), 1).toString());
    }//GEN-LAST:event_tabelTransaksiMouseClicked

    private void cbNoKamarItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbNoKamarItemStateChanged
        // TODO add your handling code here:
        
    }//GEN-LAST:event_cbNoKamarItemStateChanged

    private void tbDataTamuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbDataTamuActionPerformed
        // TODO add your handling code here:
        new Tamu().setVisible(true);
        new Tamu().setDefaultCloseOperation(new Tamu().DISPOSE_ON_CLOSE);
        this.setVisible(false);
    }//GEN-LAST:event_tbDataTamuActionPerformed

    private void tbDataKamarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbDataKamarActionPerformed
        // TODO add your handling code here:
        new Kamar().setVisible(true);
        new Kamar().setDefaultCloseOperation(new Kamar().DISPOSE_ON_CLOSE);
        this.setVisible(false);
    }//GEN-LAST:event_tbDataKamarActionPerformed

    private void tbHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbHapusActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "DELETE FROM Transaksi WHERE id_tamu='"+ idTamu.getText()+ "'";
            java.sql.Connection conn = (Connection)Koneksi.configDB();
            java.sql.PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data berhasil dihapus");
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        tampilkanDataTransaksi();
        kosongkan_form();
    }//GEN-LAST:event_tbHapusActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Dark Metal".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Transaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbJenisKamar;
    private javax.swing.JComboBox<String> cbNamaTamu;
    private javax.swing.JComboBox<String> cbNoKamar;
    private javax.swing.JTextField idTamu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner lamaMenginap;
    private javax.swing.JTable tabelTransaksi;
    private javax.swing.JButton tbDataKamar;
    private javax.swing.JButton tbDataTamu;
    private javax.swing.JButton tbHapus;
    private javax.swing.JButton tbResetInput;
    private javax.swing.JButton tbSimpanTransaksi;
    private javax.swing.JButton tbUpdate;
    private com.toedter.calendar.JDateChooser tglCheckIn;
    private javax.swing.JTextField totalBiaya;
    private javax.swing.JTextField txtTarif;
    // End of variables declaration//GEN-END:variables
}
